#include <iostream>
using namespace std;
#include "MYVector.h"

void MYVector_test_suite()
{
	cout <<"MYVector test suite started..."<<endl;
	//construction and set
	MYVector v1(1.5,3),v2(4,3);

	MYVector v3;
	v3.set(11,12);
	MYVector v4(v1);

	MYVector v5=v2,v6;
	v6.set(v3);

	//setters/getters
	v3.setX(v5.getX());
	v3.setY(v5.getY());

	//length & direction
	if (v3.lengthSquared()!=25)
		cout <<"lengthSquared fault."<<endl;
	if (v3.length()!=5)
		cout <<"length fault."<<endl;
	v6=v3.direction();

	//access operators
	if (v6('x')!=v5.direction()['x'] || v5.normalize()('y') != v6[1])
		cout <<"Access operators fault."<<endl;

	//relational operators
	if (v5.normalize()!=v6)
		cout <<"!= fault"<<endl;
	if (v2<=v1)
		cout <<"<= fault"<<endl;
	if (v2<v1)
		cout <<"< fault"<<endl;
	if (v1>v2)
		cout <<"> fault"<<endl;
	if (v1>=v2)
		cout <<">= fault"<<endl;
	if (v5!=v3)
		cout <<"!= fault"<<endl;

	//unary prefix operators
	if (v1!= +v1)
		cout <<"+prefix fault"<<endl;
	if (v2 != -(-v2))
		cout <<"-prefix fault"<<endl;

	if (--(++v3)!=v3)
		cout <<"--prefix or ++prefix fault"<<endl;

	//unary postfix operators
	if (v3++ != v5--)
		cout <<"postfix++ or postfix-- fault"<<endl;

	//binary arithmetic operators
	v1.set(4,5);
	v2.set(8,10);
	v3.set(1.5,3.5);
	v4.set(v1);
	v5=v2;
	v6=v3;

	if (v1+v4 != v2)
		cout <<" + fault"<<endl;
	if (v2-v1 != v4)
		cout <<" - fault"<<endl;
	if (v1*2 != v2)
		cout <<" * int fault"<<endl;
	if (v3*v6!=1.5*1.5+3.5*3.5)
		cout <<" * fault"<<endl;
	if (2*v1 != v2)
		cout <<" friend * fault"<<endl;
	if (v2/2 != v1)
		cout <<" / fault"<<endl;

	//assignment operators
	v6=v5=v4=v1;
	if (v1!=v4 || v1!=v5 || v1!=v6)
		cout <<"= fault"<<endl;

	v4.set(v1);
	v4+=v4+=v1;

	if (v4!=v1*4)
		cout <<"+= fault"<<endl;

	v4-=v1;
	if (v4!=v1*3)
		cout <<"-= fault"<<endl;

	v1*=2;
	if (v1!=v2)
		cout <<"*= fault"<<endl;
	v1/=2;
	if (v1*2!=v2)
		cout <<"/2 fault"<<endl;


	cout <<"MYVector test suite successful."<<endl;
}

int main()
{
	MYVector_test_suite();
	return 0;
}