#ifndef MYVector_H_
#define MYVector_H_

class MYVector
{
private:
	float x,y;												// member variables
	void doError();											// force error
public:
	//Constructors - Destructors
	MYVector();												// default constructor
	~MYVector();											// destructor
	MYVector(const MYVector & copy);						// copy constructor
	MYVector(const float x,const float y);					// init constructor


	//Setters
	void set(const MYVector &v);							// sets both x,y via another vector
	void set(const float x,const float y);					// sets both x,y
	void setX(const float x);								// sets only x
	void setY(const float y);								// sets only y
	

	//Getters
	float getX() const;										// gets x
	float getY() const;										// gets y
	
	//useful methods
	float lengthSquared() const;							// length squared, for comparison
	float length() const;									// length
	MYVector direction() const;								// direction's unit vector
	MYVector normalize() const {return direction();}		// alias for direction

	//unary prefix operators
	MYVector operator +() const;							// +Vector, does nothing
	MYVector operator -() const;							// -Vector
	MYVector& operator --();								// --Vector
	MYVector& operator ++();								// ++Vector

	//unary postfix operators
	MYVector operator ++(int temp);							// Vector++
	MYVector operator --(int temp);							// Vector--

	//binary arithmetic operators
	friend MYVector operator* (const int, const MYVector);
	MYVector operator* (const int);
	MYVector operator -(const MYVector v) const;			// Vector - v2
	MYVector operator /(const int coefficient) const;		// Vector / int
	friend MYVector operator +(const MYVector& v1, const MYVector& v2);	//v1 + v2
	friend float operator *(const MYVector& v1, const MYVector& v2);	//v1 * v2

	//binary relational operators
	bool operator >(const MYVector v) const;				// Vector > v
	bool operator <(const MYVector v) const;				// Vector < v
	bool operator >=(const MYVector v) const;				// Vector >= v
	bool operator <=(const MYVector v) const;				// Vector <= v
	bool operator !=(const MYVector v) const;				// Vector != v
	bool operator ==(const MYVector v) const;				// Vector == v

	//binary assignment operators
	MYVector& operator = (const MYVector &v);				// Vector = v
	MYVector& operator += (const MYVector v);				// Vector += v
	MYVector& operator -= (const MYVector v);				// Vector -= v
	MYVector& operator *= (const int coefficient);			// Vector *= int
	MYVector& operator /= (const int coefficient);			// Vector /= int

	//access operators
	float & operator ()(const int index)					// to access v(0) and v(1)
	{
		return (*this)[index];
	}
	float & operator ()(const char specifier)				// to access v('x') and v('y')
	{
		return (*this)[specifier];
	}
	float & operator [](const int index)					// to access v[0] and v[1]
	{
		if (index<2 && index>=0)
			return (&x)[index];
		doError();
		return x;
	}
	float & operator [](const char specifier)				// to access v['x'] and v['y']
	{
		if (specifier == 'x' || specifier == 'X')
			return x;
		if (specifier == 'y' || specifier == 'Y')
			return y;
		doError();
		return x;
	}
};

#endif /* MYVector_H_ */
