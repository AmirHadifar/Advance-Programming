#include <iostream>
using namespace std;

#include "MYString.h"

void MYString_test_suite()
{
	cout <<"MYString test suite started..."<<endl;
	MYString s1;
	MYString s2("Hello there");
	MYString s3="How do you feel?";
	MYString s4(1234567890);
	MYString s5("123456");
	MYString s6(s3);

	MYString s2_2(s2);
	MYString s3_2(s3);
	MYString s4_2(s4);
	MYString s5_2(s5);
	MYString s6_2(s6);
	if (s4!="1234567890")
		cout <<"int constructor fault"<<endl;

	if ( !(s2_2 == s2))
		cout <<"== fault"<<endl;
	if (s2_2 != s2)
		cout <<"!= fault"<<endl;
	s5+="7890";
	if (s5!=s4)
		cout <<"+=nullTerminated fault"<<endl;

	if (s2.length()!=11)
		cout <<"length() fault"<<endl;

	if (s3.substr(4,2)!="do")
		cout <<"subMYString fault"<<endl;
 	if (!(s5>=s4))
		cout <<"<= fault"<<endl;
	if (!(s5<=s4))
		cout <<"<= fault"<<endl;

	s5= "1"+s5;


	if (!(s5<s4))
		cout <<"> fault"<<endl;
	if (!(s4>s5))
		cout <<"< fault"<<endl;
	if (!(s5<=s4))
		cout <<">= fault"<<endl;
	if (!(s4>=s5))
		cout <<"<= fault"<<endl;

	MYString s6_3;
	s6_3=s6_2;
	if (s6_3!=s6_2)
		cout <<"= fault"<<endl;

	s5-=1;
	if (s5>s4)
		cout <<"-= fault"<<endl;


	//s5=s5.substr(1);
	s5+="1";
	if (s5<s4)
		cout <<"+= fault"<<endl;

	if (s2[4] != 'o')
		cout <<"[index] fault"<<endl;
	if (s2[4]!=s2(4))
		cout <<" (index) fault"<<endl;

	if (s2(6,s2.length()-1)!="there")
		cout <<"(start,end) fault"<<endl;

	cout <<"MYString test suite successful."<<endl;
	return;
}
int main()
{
	MYString_test_suite();
	return 0;
}

